from django.contrib import admin
from .models import MyProfile, MyPost, PostComment, PostLike, FollowUser
from django.contrib.admin.options import ModelAdmin
# Register your models here.


class FollowUserAdmin(ModelAdmin):
    list_display = ['profile', 'followed_by']
    search_fields = ['profile', 'followed_by']
    list_filter = ['profile', 'followed_by']


admin.site.register(FollowUser, FollowUserAdmin)


class MyPostAdmin(ModelAdmin):
    list_display = ['cr_date', 'subject', 'uploaded_by']
    search_fields = ['subject', 'uploaded_by']
    list_filter = ['cr_date', 'subject', 'uploaded_by']


admin.site.register(MyPost, MyPostAdmin)


class MyProfileAdmin(ModelAdmin):
    list_display = ['name']
    search_fields = ['name', 'status', 'phone_number']
    list_filter = ['status', 'gender']


admin.site.register(MyProfile, MyProfileAdmin)


class PostCommentAdmin(ModelAdmin):
    list_display = ['post', 'msg']
    search_fields = ['msg', 'post']
    list_filter = ['cr_date', 'flag']


admin.site.register(PostComment, PostCommentAdmin)


class PostLikeAdmin(ModelAdmin):
    list_display = ['post', 'liked_by']
    search_fields = ['liked_by', 'post']
    list_filter = ['cr_date']


admin.site.register(PostLike, PostLikeAdmin)