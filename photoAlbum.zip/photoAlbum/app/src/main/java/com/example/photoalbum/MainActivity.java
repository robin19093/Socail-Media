package com.example.photoalbum;

import androidx.appcompat.app.AppCompatActivity;

import android.icu.util.ICUUncheckedIOException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button previous, next;
    ImageView pic;
    TextView textView2;
    int currImage = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void previous(View view) {
        String idx = "pic" + currImage;
        int x = this.getResources().getIdentifier(idx, "id", getPackageName());
        pic = findViewById(x);
        pic.setAlpha(0f);


        currImage = (5+ currImage - 1)%5;
        String idy = "pic" + currImage;
        int y = this.getResources().getIdentifier(idy, "id", getPackageName());
        pic = findViewById(y);
        pic.setAlpha(1f);
    }

    public void next(View view) {
        String idx = "pic" + currImage;
        int x = this.getResources().getIdentifier(idx, "id", getPackageName());
        pic = findViewById(x);
        pic.setAlpha(0f);


        currImage = (currImage + 1)%5;
        String idy = "pic" + currImage;
        int y = this.getResources().getIdentifier(idy, "id", getPackageName());
        pic = findViewById(y);
        pic.setAlpha(1f);
    }
}